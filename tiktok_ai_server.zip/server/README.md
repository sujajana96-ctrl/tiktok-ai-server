# TikTok AI Content Generator - Backend

## Setup
```bash
cd server
npm install
cp .env.example .env
npm run dev
```

## Endpoints
- POST /api/generate-variations
- POST /api/generate-script
- POST /api/generate-voice
- POST /api/compose-video
- POST /api/preview-composite

## Notes
- Replace storage.js with S3/GCS integration for production
- Implement ffmpeg.js properly for real video composition
