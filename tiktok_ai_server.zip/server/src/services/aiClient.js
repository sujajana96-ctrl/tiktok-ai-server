const fetch = require('node-fetch');
const fs = require('fs');
const { uploadFile } = require('./storage');
const { v4: uuidv4 } = require('uuid');

async function generateVariations(localImagePath, productName){
  const results = [];
  const url = await uploadFile(localImagePath, `variations/${uuidv4()}.jpg`);
  results.push(url);
  return results;
}

async function generateScript(productName='Product', tone='casual', lengthSeconds=20){
  const prompt = `Buat script TikTok singkat ${lengthSeconds}s untuk produk: ${productName}. Tone: ${tone}. Sertakan hook di awal (3 kata) dan call to action.`;
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
    body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 300 })
  });
  const json = await res.json();
  const script = json.choices?.[0]?.message?.content?.trim() || `Coba produk ${productName}!`;
  return script;
}

async function generateVoice(script, voice='Natural Female'){
  const r = await fetch('https://api.elevenlabs.io/v1/text-to-speech/standard', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'xi-api-key': process.env.ELEVENLABS_API_KEY },
    body: JSON.stringify({ text: script, voice: voice })
  });
  const arrayBuffer = await r.arrayBuffer();
  const tmpPath = `/tmp/tts-${uuidv4()}.mp3`;
  fs.writeFileSync(tmpPath, Buffer.from(arrayBuffer));
  const audioUrl = await uploadFile(tmpPath, `audio/${uuidv4()}.mp3`);
  return audioUrl;
}

async function composeVideo(images, audioUrl, script){
  const outPath = `/tmp/out-${uuidv4()}.mp4`;
  const { runCompose } = require('../utils/ffmpeg');
  await runCompose(images, audioUrl, script, outPath);
  const videoUrl = await uploadFile(outPath, `videos/${uuidv4()}.mp4`);
  return videoUrl;
}

async function previewComposite(images, script){
  const outPath = `/tmp/preview-${uuidv4()}.mp4`;
  const { runPreview } = require('../utils/ffmpeg');
  await runPreview(images, script, outPath);
  const previewUrl = await uploadFile(outPath, `previews/${uuidv4()}.mp4`);
  return previewUrl;
}

module.exports = { generateVariations, generateScript, generateVoice, composeVideo, previewComposite };
