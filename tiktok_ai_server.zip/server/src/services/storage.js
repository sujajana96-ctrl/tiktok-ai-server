const fs = require('fs');
const path = require('path');

async function uploadFile(localPath, destPath){
  // dev mode: just move file to /tmp/public and return path
  const outPath = path.join('/tmp/public', destPath);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.copyFileSync(localPath, outPath);
  return `http://localhost:3000/public/${destPath}`;
}

module.exports = { uploadFile };
