const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const fetch = require('node-fetch');
const { v4: uuidv4 } = require('uuid');

async function downloadToTmp(url, outPath){
  const res = await fetch(url);
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(outPath, buffer);
  return outPath;
}

async function runCompose(imageUrls, audioUrl, script, outPath){
  return new Promise((resolve, reject)=>{
    // TODO: implement ffmpeg composition
    // For now, just resolve to simulate
    fs.writeFileSync(outPath, 'dummy video data');
    resolve();
  });
}

async function runPreview(imageUrls, script, outPath){
  await runCompose(imageUrls, '/tmp/placeholder.mp3', script, outPath);
}

module.exports = { runCompose, runPreview };
