const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ dest: '/tmp/uploads' });
const { generateVariations, generateScript, generateVoice, composeVideo, previewComposite } = require('../services/aiClient');

router.post('/generate-variations', upload.single('image'), async (req, res) => {
  try{
    const productName = req.body.productName || '';
    const filePath = req.file.path;
    const urls = await generateVariations(filePath, productName);
    res.json({ variations: urls });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});

router.post('/generate-script', async (req, res) => {
  try{
    const { productName, tone, lengthSeconds } = req.body;
    const script = await generateScript(productName, tone, lengthSeconds);
    res.json({ script });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});

router.post('/generate-voice', async (req, res) => {
  try{
    const { script, voice } = req.body;
    const audioUrl = await generateVoice(script, voice);
    res.json({ audioUrl });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});

router.post('/compose-video', async (req, res) => {
  try{
    const { images, audioUrl, script } = req.body;
    const videoUrl = await composeVideo(images, audioUrl, script);
    res.json({ videoUrl });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});

router.post('/preview-composite', async (req, res) => {
  try{
    const { images, script } = req.body;
    const previewUrl = await previewComposite(images, script);
    res.json({ previewUrl });
  }catch(err){ console.error(err); res.status(500).json({ error: err.message }); }
});

module.exports = router;
